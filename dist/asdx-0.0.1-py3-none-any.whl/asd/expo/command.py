def main():
    import os
    os.system(f'explorer {os.getcwd()}')
