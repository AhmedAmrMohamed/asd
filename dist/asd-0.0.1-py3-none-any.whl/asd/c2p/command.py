def main():
    from . import Main
    Main.main_func()
